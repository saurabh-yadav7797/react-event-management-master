import React, { Component } from 'react';
import Controller from './controller';

export default class AuthController extends Controller{
    constructor(props){
        super(props);
    }
}